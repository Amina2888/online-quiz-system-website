<nav class="navbar navbar-expand-lg pt-3">
  <div class="container-fluid">

    <h1><a class="navbar-brand" href="index.php">Online Quiz </a></h1>
    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="welcome.php">Home</a>
        </li>
</ul>
    <form class="d-flex navbar-links" >
        <a class="btn  mx-2" type="submit" href="signup.php">Signup</a>
        <a class="btn  mx-2" type="submit" href="login.php">Login</a>
        <a class="btn  mx-2" type="submit" href="logout.php">Logout</a>
        <a  class="btn  mx-2" href=" services.php">Services</a>
        <a class="btn  mx-2" href="contactus.php">Contact Us</a>
    </form>
    

  </div>
</nav>